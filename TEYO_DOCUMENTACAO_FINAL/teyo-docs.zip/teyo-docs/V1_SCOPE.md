# V1_SCOPE.md

## INCLUI NO V1

- Conversa principal com TEYO (single-thread, sem chats separados).
- Módulos: Tarefas, Hábitos, Objetivos, Estudos, Carreira, Finanças, Mercado, Casa, Agenda, Notícias, Relatórios, Pomodoro (opcional dentro de Tarefas), Gamificação, Mascote.
- Home com hierarquia: 1) conversa com TEYO, 2) progresso, 3) tarefas/planejamento, depois agenda/plano do dia/notícias/blocos gerais.
- LLM local (Qwen3.5-4B) via camada de abstração (LLM Provider/Adapter).
- Motor de Padrões (frequência, exceção vs. tendência, promoção/rebaixamento de padrão).
- Planejamento diário com reorganização sob comando do usuário.
- Tool calling para todas as ações que alteram dados.
- Banco de dados single-user, com schema já preparado para `user_id` em todas as tabelas relevantes.
- Mascote com expressões reativas, evolução visual pré-definida, cor customizável.
- Notícias personalizáveis por usuário (mesmo com um único usuário ativo no V1).

## NÃO INCLUI NO V1 (FORA DO V1)

- Módulo de pets (DECIDIDO — removido explicitamente).
- Multiusuário completo (convites, permissões, telas de administração de conta).
- Personalização de mascote além de cor (expressões, acessórios, skins alternativas).
- Apps nativos iOS/Android (V1 é web/PWA).
- Qualquer integração com API paga de LLM em produção.
- Funcionalidade de busca de vagas com API paga (mecanismo concreto ainda A DEFINIR, mas o requisito de não ter custo de API de LLM é DECIDIDO).

## A DEFINIR (bloqueiam decisões técnicas, não bloqueiam a documentação)

- Runtime exato de hospedagem do Qwen3.5-4B (ex.: llama.cpp, Ollama, vLLM) — ver `LLM.md`.
- Valores numéricos do Motor de Padrões (tamanho da janela de observação, limiar de confiança) — ver `PATTERN_ENGINE.md`.
- Mecanismo concreto de busca de vagas no módulo Carreira — ver `MODULES/CAREER.md`.
- Regras exatas de XP e níveis de gamificação — ver `GAMIFICATION.md`.
- Estrutura de framework de frontend/backend (não foi decidida stack específica nesta conversa) — ver `ARCHITECTURE.md`.

## Regra para o Claude Code

Nenhum item da lista "NÃO INCLUI NO V1" deve ser implementado, mesmo que pareça simples ou "só um MVP". Nenhum item "A DEFINIR" deve virar decisão definitiva sem antes voltar para Jams com a OPÇÃO RECOMENDADA documentada no arquivo correspondente.

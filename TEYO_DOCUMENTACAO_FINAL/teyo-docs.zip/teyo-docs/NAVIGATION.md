# NAVIGATION.md

DECIDIDO (doc. 3, item 43): a navegação já definida anteriormente é considerada boa e deve ser preservada.

## Estrutura

- **Home**: dashboard e ponto de entrada. Não concentra toda a funcionalidade.
- **Home → módulo**: cada módulo com complexidade própria (Tarefas, Hábitos, Objetivos, Estudos, Carreira, Finanças, Mercado, Casa, Agenda, Notícias, Relatórios) tem tela própria, acessível a partir de um bloco na Home.
- **Home → conversar com TEYO → tela TEYO**: existe uma tela principal de conversa. DECIDIDO: não existem dois chats diferentes; um único ponto de entrada de conversa.
- **Módulo → voltar → Home**.

## Blocos na Home (DECIDIDO, doc. 3, item 7)

Cada módulo tem um bloco de acesso rápido na Home (ex.: bloco "Finanças" → ao tocar, abre a tela de Finanças). Os blocos não precisam exibir todos os detalhes do módulo — apenas um resumo/atalho.

## Regra geral

Nem tudo precisa acontecer dentro da Home. Módulos com complexidade própria (formulários, listas longas, filtros) vivem em telas dedicadas.

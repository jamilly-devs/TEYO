# DEFINITION_OF_DONE.md

"TEYO V1 está pronto" quando todos os itens abaixo forem verdadeiros e verificáveis:

1. Todos os módulos listados em "INCLUI NO V1" (`V1_SCOPE.md`) têm CRUD funcional pela tela e pela conversa, com paridade de resultado no banco.
2. Nenhum item listado em "NÃO INCLUI NO V1" está presente na build.
3. O LLM roda localmente (Qwen3.5-4B) através do LLM Adapter, sem nenhuma chamada a API paga de LLM em nenhum caminho de código de produção.
4. Toda ação de escrita realizada pela conversa passa por uma tool com validação de parâmetros (`TOOLS.md`), verificável por teste de integração.
5. As regras de `BUSINESS_RULES.md` têm ao menos um teste automatizado cada, e todos passam.
6. O Motor de Padrões não promove nenhum padrão a `active` a partir de um único evento — comprovado por teste com o cenário de exemplo do histórico (item de `TESTING.md`).
7. Toda ação destrutiva exige confirmação explícita antes da execução, comprovado por teste de fluxo.
8. Os critérios de `ACCEPTANCE_CRITERIA.md` passam integralmente.
9. Os 15 fluxos de `FLOWS.md` foram exercitados manualmente ou por teste E2E, incluindo caminho de erro/ambiguidade.
10. `DOCUMENTATION_AUDIT.md` não contém nenhuma contradição não resolvida classificada como bloqueante.
11. Todo item que permanecer "A DEFINIR" ao final da FASE 11 do roadmap está listado explicitamente em um documento de pendências entregue junto com o V1, e nenhuma dessas pendências foi resolvida arbitrariamente pelo Claude Code sem registro da decisão tomada.

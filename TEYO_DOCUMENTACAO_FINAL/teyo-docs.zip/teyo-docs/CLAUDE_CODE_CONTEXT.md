# CLAUDE_CODE_CONTEXT.md

Resumo compacto do TEYO V1, para uso como contexto inicial do agente.

TEYO é um assistente pessoal conversacional (não um gerenciador de tarefas comum) com personalidade de "amigão": informal, tranquilo, sem tom corporativo. Existe uma única conversa principal — não há chats separados por assunto.

Arquitetura: Usuário → Interface → Orquestrador → LLM local (Qwen3.5-4B, via camada de abstração/Adapter) → Tools → Sistema/Banco → resultado volta ao LLM → resposta ao usuário. O LLM nunca acessa banco, calcula números, decide regras de negócio ou executa ação diretamente — tudo passa por tools com contrato fixo. Cálculos, memória, padrões e permissões pertencem ao sistema, não ao LLM.

V1 é single-user, mas todo dado carrega `user_id` para preparar multiusuário futuro. Sem dependência de API paga de LLM em produção — Claude/Claude Code é usado só para desenvolver.

Módulos do V1: Tarefas, Hábitos, Objetivos, Estudos (categoria de Tarefas/Agenda), Carreira (acompanhamento manual no V1, busca de vagas é futuro), Finanças, Mercado, Casa (categoria de Tarefas, sem pets), Agenda, Notícias (personalizadas por usuário), Relatórios, Pomodoro (opcional em tarefas), Gamificação (XP/nível/evolução, regras exatas ainda a confirmar), Mascote (evolução pré-definida, só cor é customizável).

Motor de Padrões: componente do próprio sistema (não é LLM, não é API paga) que observa histórico do usuário e diferencia exceção isolada de mudança real de rotina, usando janelas de observação (valores exatos a confirmar). Um único evento nunca vira padrão.

Memória: pertence ao sistema, separada em contexto de conversa, memória temporária, memória permanente/preferências, histórico bruto e padrões — cada uma em seu lugar, nunca "possuída" pelo LLM.

Regra de ouro: quando faltar informação, o TEYO pergunta; quando não souber, admite; quando não executou algo, não diz que executou; ações destrutivas ou ambíguas exigem confirmação do usuário.

Ver `V1_SCOPE.md` para o que entra e o que não entra nesta versão, e `BUSINESS_RULES.md` para a lista completa de regras.

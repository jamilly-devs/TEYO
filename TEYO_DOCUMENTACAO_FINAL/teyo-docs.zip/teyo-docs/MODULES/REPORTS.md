# MODULES/REPORTS.md — Relatórios

1. **Objetivo**: apresentar indicadores de produtividade, progresso, objetivos, rotina e hábitos.
2. **Funcionalidades**: relatório de produtividade, resumo semanal, fechamento diário (resumo do que foi feito, pendências, avanço em objetivos — DECIDIDO conforme memória de contexto do usuário).
3. **Telas**: tela de Relatórios.
4. **Componentes**: gráficos/indicadores (formato exato A DEFINIR).
5. **Dados**: agrega `tasks`, `habit_logs`, `goals`, `productivity_logs`, `gamification_events`.
6. **Ações**: `get_productivity_report` (ver `TOOLS.md`).
7. **Regras de negócio**: DECIDIDO — números vêm sempre do sistema; o LLM interpreta e explica, nunca inventa números.
8. **Interação com TEYO**: usuário pode perguntar "por que minha produtividade caiu essa semana?" e o TEYO responde interpretando dados já calculados pelo sistema.
9. **Interação com outros módulos**: consome dados de todos os módulos de atividade.
10. **V1**: relatório de produtividade + fechamento diário + resumo semanal.
11. **Depois**: exportação de relatórios, relatórios comparativos entre usuários (multiusuário) — FORA DO V1.

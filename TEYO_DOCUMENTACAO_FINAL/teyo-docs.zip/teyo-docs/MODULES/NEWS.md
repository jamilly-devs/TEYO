# MODULES/NEWS.md — Notícias

1. **Objetivo**: exibir notícias relevantes ao usuário, personalizadas por tópico de interesse.
2. **Funcionalidades**: definir tópicos de interesse (ex.: tecnologia/QA), exibir feed de notícias desses tópicos.
3. **Telas**: bloco de notícias na Home (não há decisão de tela dedicada além da Home).
4. **Componentes**: card de notícia.
5. **Dados**: `news_preferences` (ver `DATABASE.md`) — tópicos por `user_id`.
6. **Ações**: definição de tópicos de interesse — nome de tool específico A DEFINIR; pode ser tratado via `memory_entries`/preferências ou tabela própria (`news_preferences` já prevista em `DATABASE.md`).
7. **Regras de negócio**: personalização é por usuário desde o schema, mesmo com apenas um usuário ativo no V1 (DECIDIDO).
8. **Interação com TEYO**: usuário pode declarar interesse por conversa (ex.: "me mostra mais notícias de tecnologia").
9. **Interação com outros módulos**: nenhuma dependência direta de outros módulos.
10. **V1**: definição de tópicos de interesse de um usuário + exibição de feed.
11. **A DEFINIR**: fonte técnica das notícias (agregador, API gratuita de notícias, RSS) — não há decisão registrada no histórico; precisa ser esclarecido antes da FASE correspondente do roadmap.
